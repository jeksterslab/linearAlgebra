library(testthat)
library(linearAlgebra)

test_check("linearAlgebra")
