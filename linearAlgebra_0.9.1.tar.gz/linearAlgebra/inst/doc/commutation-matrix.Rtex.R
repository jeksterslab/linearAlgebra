## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(linearAlgebra)

## -----------------------------------------------------------------------------
x_i <- matrix(
  data = c(
    1.0, 0.5, 0.4,
    0.5, 1.0, 0.6,
    0.4, 0.6, 1.0
  ),
  ncol = 3
)
m_i <- dim(x_i)[1]
kcap(m_i)
kcap(m_i) %*% vec(x_i)

all.equal(
  c(kcap(m_i) %*% vec(x_i)), vech(t(x_i)),
  check.names = FALSE
)

