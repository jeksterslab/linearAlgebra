## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(linearAlgebra)

## -----------------------------------------------------------------------------
x_i <- matrix(
  data = c(
    1.0, 0.5, 0.4,
    0.5, 1.0, 0.6,
    0.4, 0.6, 1.0
  ),
  ncol = 3
)
m_i <- dim(x_i)[1]
dcap(m_i)
dcap(m_i) %*% vech(x_i)

all.equal(c(dcap(m_i) %*% vech(x_i)), vec(x_i))

