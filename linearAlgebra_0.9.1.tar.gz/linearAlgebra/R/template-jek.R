.jek <- function() {
  message(
    "This package was developed by Ivan Jacob Agaloos Pesigan."
  )
}
