#' @author Ivan Jacob Agaloos Pesigan
#'
#' @title linearAlgebra: Linear Algebra
#'
#' @description A collection of functions related to linear algebra.
#'
#' @docType package
#' @name linearAlgebra
#' @keywords linearAlgebra package
NULL
